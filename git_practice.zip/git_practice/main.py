# developer1method(), developer2method(), developer3method()
# name, surname, email, cohort, age, gender, birthdate, speciality, country of origin

def developer1method(name: str = "Iskender", email: str = "isken.majitov1@gmail.com", cohort = "Computer Science",
                     age = 19, gender = "male", birthdate = "10.10.2002", speciality = "developer", country_of_origin = "KG"): #Iskender
    print(f"Name of developer this method is {name}")
    print(f"Email of developer this method is {email}")
    print(f"Cohort of developer this method is {cohort}")
    print(f"Age of developer this method is {age}")
    print(f"Gender of developer this method is {gender}")
    print(f"birthdate of dev is {birthdate}")



def developer2method(name: str = "Tariq", surname: str = "Aziz", email: str = "axixtariq123@gmail.com", cohort = "Computer Science",
                     age = 20, gender = "male", birthdate = "04.04.2002", speciality = "coding", country_of_origin = "Pakistan"): #Tariq
    print(f"Name is {name}")
    print(f"surname is {surname}")
    print(f"Email is {email}")
    print(f"Cohort is {cohort}")
    print(f"Age is {age}")
    print(f"Gender is {gender}")
    print(f"country is {country_of_origin}")
    print(f"speciality is {speciality}")
    print(f"birthdate is {birthdate}")
    


def developer3method():
    print("Jasurbek")
    print("Sadiev")
    print("jasursadiev2002@gmail.com")
    print("Computer Science")
    print(20)
    print("male")
    print("19.04.2002")
    print("Computer Scientist")
    print("Tajikistan")

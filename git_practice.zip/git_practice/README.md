# Git Practice Project

## Group members list:

### **Iskender** - Team Leader :D
### **Jasur** - Senior Java Script
### **Tariq** - Team Manager 

# Iskender Responsbilities:
### 1. Initialize and add all group members
### 2. Manage team members
### 3. Create features for features1.py
### 4. Add body for method in method1developer

# Jasur Responsbilities:
### 1. Clone git repo
### 2. Create features for features3.py
### 3. Add body for method in method3developer

# Tariq Responsbilities:
### 1. Clone git repo
### 2. Create features for features2.py
### 3. Add body for method in method2developer
